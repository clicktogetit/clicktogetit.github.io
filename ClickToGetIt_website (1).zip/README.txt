# ClickToGet It!
Static homepage for ClickToGet It! — new and refurbished phones and laptops.

## Publish free with GitHub Pages
1. Create a GitHub account.
2. Create a repository named `YOURUSERNAME.github.io`.
3. Upload `index.html` and `style.css`.
4. Go to Settings → Pages → Deploy from a branch → main → /(root) → Save.
5. Open `https://YOURUSERNAME.github.io`.

Replace the sample products/prices with your real inventory before advertising.
